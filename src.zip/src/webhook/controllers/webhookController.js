module.exports = class WebhookController {
  constructor() {
    this.generateAndUploadAudio = require('../utils/generate-speech.js');
    this.client = require('../config/eleven-labs-config.js');
  }

  async sendMessage(req, res) {
    const text = req.body

    console.log(text)
  }

  async generateAndUploadAudio(text, lead_id) {
    return this.generateAndUploadAudio(text, this.client, lead_id);
  }
}